#pragma once
void GameTitle();
int KeyController();
int MenuDraw();
void InfoDraw();
enum class KEY {
	UP, DOWN, SPACE
};