#pragma once
void DrawEnd(int score);
